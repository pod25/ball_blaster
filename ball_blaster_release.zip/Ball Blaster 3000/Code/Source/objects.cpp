/*
 * File: objects.cpp
 */
#include "common.h"
