/*
 * File: ball.cpp
 */
#include "common.h"

//