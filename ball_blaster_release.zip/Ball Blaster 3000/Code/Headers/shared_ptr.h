#ifndef SHARED_PTR_H
#define SHARED_PTR_H

////////////////////////////////////////////////////////////////
// HEADER INCLUDE FILES
////////////////////////////////////////////////////////////////

#include <new>
using std::bad_alloc;
#include <stdexcept>
using std::invalid_argument;

////////////////////////////////////////////////////////////////
// CLASS DECLARATIONS
////////////////////////////////////////////////////////////////

template<typename T> 
class shared_ptr {
    T* value;
    int* countptr;

    //Methods
    void release();
    inline void settozero();
    void setto(const shared_ptr<T>&);
    void setto(T*);
 public:
    //Methods
    void clear();
	inline T*   getvalue() const;
    inline int  getcount() const;
	inline bool empty()    const;
    //Operators
    inline T& operator *() const;
    //T& operator [](unsigned int) throw(std::out_of_range); //Put in shared_array
    shared_ptr<T>& operator =(shared_ptr<T>&);
    shared_ptr<T>& operator =(T*);
	bool operator ==(shared_ptr<T>);
	bool operator ==(T*);
    template<typename T2> inline T* operator +(T2) const;
    template<typename T2> inline T* operator -(T2) const;

    //Constructors and destructor
    shared_ptr(); //Default constructor
    shared_ptr(const shared_ptr<T>&); //Copy constructor
	shared_ptr(T*);
    ~shared_ptr();
};

////////////////////////////////////////////////////////////////
// PRIVATE CLASS METHODS
////////////////////////////////////////////////////////////////

/************************************************************************
 * release()
 * Caution: This function always has to be followed up by code that makes
 * sure value and countptr get their proper values.
 ************************************************************************/

template<typename T>
void shared_ptr<T>::release() {
	if (countptr && !--*countptr) {
		delete value;
		delete countptr;
	}
}

template<typename T>
inline void shared_ptr<T>::settozero() {value = 0; countptr = 0;}

template<typename T>
void shared_ptr<T>::setto(const shared_ptr<T>& sp) {
	if (&sp == this) throw invalid_argument("Trying to set shared pointer to itself");
	value = sp.value;
	if (countptr = sp.countptr) ++*countptr;
	//else if (value) throw invalid_argument("Trying to copy corrupt shared pointer"); //Won't happen
}

template<typename T>
void shared_ptr<T>::setto(T* p) {
	if (value = p) {
		try {countptr = new int; *countptr = 0;}
		catch (bad_alloc ba) {
			settozero();
			throw ba;
		}
	}
	else settozero();
}

////////////////////////////////////////////////////////////////
// PUBLIC CLASS METHODS
////////////////////////////////////////////////////////////////

template<typename T>
void shared_ptr<T>::clear() {
	release();
	settozero();
}

template<typename T>
inline T* shared_ptr<T>::getvalue() const {return value;}

template<typename T>
inline int shared_ptr<T>::getcount() const {return countptr ? *countptr : 0;}

template<typename T>
inline bool shared_ptr<T>::empty() const {return !value;}

////////////////////////////////////////////////////////////////
// OPERATORS
////////////////////////////////////////////////////////////////

template<typename T>
inline T& shared_ptr<T>::operator *() const
{return *value;}

template<typename T>
shared_ptr<T>& shared_ptr<T>::operator =(shared_ptr<T>& sp) {
    if (&sp == this) return this;
    release();
    setto(sp);
    return this;
}
template<typename T>
shared_ptr<T>& shared_ptr<T>::operator =(T* p) {
    if (value == p) throw invalid_argument("How did you get that pointer?");
    release();
    setto(p);
    return this;
}

template<typename T> bool shared_ptr<T>::operator ==(shared_ptr<T> rhs) {return value == rhs.value;}
template<typename T> bool shared_ptr<T>::operator ==(T*            rhs) {return value == rhs      ;}

template<typename T> template<typename T2> inline T* shared_ptr<T>::operator +(T2 term) const {return value+term;}
template<typename T> template<typename T2> inline T* shared_ptr<T>::operator -(T2 term) const {return value-term;}

////////////////////////////////////////////////////////////////
// CONSTRUCTORS AND DESTRUCTOR
////////////////////////////////////////////////////////////////
template<typename T> shared_ptr<T>:: shared_ptr() {settozero();} //Default constructor
template<typename T> shared_ptr<T>:: shared_ptr(const shared_ptr<T>& rhs) {setto(rhs);} //Copy constructor
template<typename T> shared_ptr<T>:: shared_ptr(T*                   rhs) {setto(rhs);}
template<typename T> shared_ptr<T>::~shared_ptr() {release();}

#endif /* SHARED_PTR_HPP */