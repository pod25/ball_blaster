In order to build the Visual Studio project from scratch, Visual Studio (Express works fine) has to be installed, and the dll files in the parent directory to this directory have to be copied into here, and the libraries in the folder "Build libraries" have to be installed, accordingly to the instructions here:

http://www.lazyfoo.net/SDL_tutorials/lesson01/windows/msvsnet0508e/index.php (SDL-devel-1.2.14-VC8.zip)

and here:

http://www.lazyfoo.net/SDL_tutorials/lesson03/windows/msvsnet0508e/index.php (SDL_image-devel-1.2.10-VC, SDL_ttf-devel-2.0.9-VC8.zip and sdl_gfx-2017.zip)

To be able to run the program, the "Images", "Fonts" and "Levels" folders have to be copied into the same folder as the dll files.