/*
 * File: event_handler.cpp
 */
#include "common.h"

//